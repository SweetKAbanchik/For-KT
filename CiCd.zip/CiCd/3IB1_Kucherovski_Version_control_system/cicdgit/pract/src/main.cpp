#include "math.h"
#include <iostream>

using namespace std;


int main() {
    cout << sum(1, 2) << endl;
    return 0;
}