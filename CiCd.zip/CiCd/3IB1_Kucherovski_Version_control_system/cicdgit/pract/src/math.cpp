#ifndef CPP_MATH_CPP
#define CPP_MATH_CPP

#include "math.h"

int sum(int a, int b){
    return a + b;
}

#endif //CPP_MATH_CPP