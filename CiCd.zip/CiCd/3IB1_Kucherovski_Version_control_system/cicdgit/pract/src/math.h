#ifndef CPP_MATH_H
#define CPP_MATH_H


int sum(int a, int b);


#endif //CPP_MATH_H
