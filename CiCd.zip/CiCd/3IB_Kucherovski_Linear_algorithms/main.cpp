#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int kingX, kingY, rookX, rookY, bishopX, bishopY;
    cout << "Введите координаты короля" << endl;
    cin >> kingX >> kingY;

    cout << "Введите координаты ладьи" << endl;
    cin >> rookX >> rookY;

    cout << "Введите координаты слона" << endl;
    cin >> bishopX >> bishopY;

    if (kingX == rookX || kingY == rookY) {
        cout << "rook" << endl;
    }
    else if (abs(kingX - bishopX) == abs(kingY - bishopY)) {
        cout << "bishop" << endl;
    }
    else {
        cout << "none" << endl;
    }


    return 0;
}
