package org.example;

import static java.lang.Math.abs;

public class Chess {
    public static  String solve(int kingX, int kingY, int rookX, int rookY, int bishopX, int bishopY) {

        //     Проверяем, угрожает ли королю ладья или слон
        if (kingX == rookX || kingY == rookY) {
            return "rook";
        }

        // Проверяем, есть ли угроза от слона
        if (Math.abs(kingX - bishopX) == Math.abs(kingY - bishopY)) {
            return "bishop";
        }
        return "safe";
    }
}


