#ifndef CPPKT2_DCR_CPP
#define CPPKT2_DCR_CPP

#include <cmath>

double dcr(double a, double b, double c){
    return b*b - 4*a*c;
};
double qrt(double a){
    return sqrt(a);
};


#endif //CPPKT2_DCR_H
