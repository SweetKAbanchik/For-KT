#ifndef CPPKT2_DCR_H
#define CPPKT2_DCR_H


double dcr(double a, double b, double c);
double qrt(double a);


#endif //CPPKT2_DCR_H
