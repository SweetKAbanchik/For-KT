#include <iostream>
#include "dcr.h"

int main() {
    double a, b, c;
    double discriminant, x1, x2;

    std::cout << "Введите коэффициенты a, b и c: ";
    std::cin >> a >> b >> c;
    discriminant = dcr(a,b,c);
    if (discriminant > 0) {
        x1 = (-b + qrt(discriminant)) / (2 * a);
        x2 = (-b - qrt(discriminant)) / (2 * a);
        std::cout << "Корни уравнения: " << x1 << " и " << x2 << std::endl;
    } else if (discriminant == 0) {
        x1 = -b / (2 * a);
        std::cout << "Уравнение имеет один корень: " << x1 << std::endl;
    } else {
        std::cout << "Корни уравнения являются комплексными числами:\n";
    }

    return 0;
}
